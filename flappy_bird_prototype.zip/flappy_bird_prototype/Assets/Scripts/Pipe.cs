﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pipe : MonoBehaviour
{
    public GameManager gm;
    public bool isEnd = false;

    float speed = 0.1f;
    float offset = 0;

    private void Update () {
        if (!isEnd) {
            float posX = transform.position.x;

            posX -= speed;
            if (posX < -6f) {
                posX = 6f;
                offset = Random.Range(-1f, 1f);
                gm.addScore();
            }


            transform.position = new Vector3(posX, offset, 0);
        }
    }
}
