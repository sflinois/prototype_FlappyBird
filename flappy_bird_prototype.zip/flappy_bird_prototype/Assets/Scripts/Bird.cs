﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bird : MonoBehaviour
{
    public GameManager gm;
    public bool isEnd = false;

    float fallSpeed = 0.1f;
    float jumpSpeed = 0f;


    void jump () {
        jumpSpeed = 0.25f;
    }

    private void OnTriggerEnter (Collider other) {
        gm.endGame();
    }

    // Update is called once per frame
    void Update()
    {
        if (!isEnd) {
            float posY = transform.position.y;

            if (Input.GetKeyDown(KeyCode.Space)) {
                jump();
            }

            if (jumpSpeed > 0)
                jumpSpeed -= 0.01f;
            posY = posY + jumpSpeed - fallSpeed;

            transform.position = new Vector3(0, posY, 0);
        }
    }
}
