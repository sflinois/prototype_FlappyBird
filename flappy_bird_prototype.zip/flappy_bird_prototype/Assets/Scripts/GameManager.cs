﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class GameManager : MonoBehaviour
{

    bool isEnd = false;
    public Bird bird;
    public Pipe pipe;
    public Text text;

    int score = 0;

    public void endGame () {
        isEnd = true;
        bird.isEnd = true;
        pipe.isEnd = true;
    }

    public void addScore() {
        score++;
        text.text = "Score : " + score;
    }
}
